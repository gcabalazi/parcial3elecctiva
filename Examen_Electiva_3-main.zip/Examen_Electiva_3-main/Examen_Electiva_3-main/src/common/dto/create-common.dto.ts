export class CreateCommonDto {}
